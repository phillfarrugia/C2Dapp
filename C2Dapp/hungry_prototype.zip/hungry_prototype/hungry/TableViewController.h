//
//  TableViewController.h
//  hungry
//
//  Created by Robin Wohlers-Reichel on 21/03/2014.
//
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface TableViewController : UITableViewController <UITableViewDataSource>
    @property (strong, nonatomic) NSArray *googlePlacesArrayFromAFNetworking;
    @property (strong, nonatomic) NSArray *finishedGooglePlacesArray;
    @property(nonatomic) NSString *formattedLocationString;
@end
