//
//  AppDelegate.h
//  hungry
//
//  Created by Robin Wohlers-Reichel on 21/03/2014.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
