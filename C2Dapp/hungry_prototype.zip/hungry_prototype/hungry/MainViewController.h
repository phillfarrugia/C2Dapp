//
//  MainViewController.h
//  hungry
//
//  Created by Robin Wohlers-Reichel on 22/03/2014.
//
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "TableViewController.h"

@interface MainViewController : UIViewController <CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *latLngLocation;
@property (weak, nonatomic) IBOutlet UIButton *feedMeButton;

@end
